package com.example.csgraprojectmust.bloodpoint;

import android.support.annotation.NonNull;
import android.telephony.mbms.StreamingServiceInfo;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class FireBaseFunctions {
   static private FirebaseFirestore db= FirebaseFirestore.getInstance();
   static private CollectionReference db_collection=db.collection("users");
    static private CollectionReference db_collection2=db.collection("requests");
    static private CollectionReference db_collection3=db.collection("RequestInfo");
    static private CollectionReference db_collection4=db.collection("doneRequests");
    static String x;
  static private boolean added,result,canceled;
    static public boolean NewRequestAdded;
    static public boolean addToDataBase(){
        UserModule module=new UserModule(StaticUserModule.UserName, StaticUserModule.Password,StaticUserModule.DateofBirth,
                StaticUserModule.MobileNumber,StaticUserModule.Gender,StaticUserModule.BloodType,
                StaticUserModule.City,StaticUserModule.lastMedicalChick,StaticUserModule.lastDonation,
                StaticUserModule.location,StaticUserModule.Dentist,StaticUserModule.Virusc,StaticUserModule.others,
                StaticUserModule.Operation,StaticUserModule.medicalAvailability);
     try {
         db_collection.document().set(module).addOnSuccessListener(new OnSuccessListener<Void>() {
             @Override
             public void onSuccess(Void aVoid) {
                 Log.i("Add Data","Added");
                 added=true;
             }
         }).addOnFailureListener(new OnFailureListener() {
             @Override
             public void onFailure(@NonNull Exception e) {
                 Log.d("Add Data","Error "+e);
                 added=false;
             }
         });
     }catch (Exception e){
         Log.i("Error ",e.toString());
     }
return added;
    }
    static public void getId(){
        db_collection.whereEqualTo("mobileNumber",StaticUserModule.MobileNumber)
            .whereEqualTo("password",StaticUserModule.Password)
            .get()
            .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                @Override
                public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        for(QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots){
                            StaticUserModule.id=(documentSnapshot.getId());
                    }

                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {

                }
            });


    }
    static public void LoadData1(){
        db_collection.document(StaticUserModule.id).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
               // UserModule note=documentSnapshot.toObject(UserModule.class);
                StaticUserModule.UserName=documentSnapshot.getString("userName");
                StaticUserModule.DateofBirth=documentSnapshot.getString("dateofBirth");
                StaticUserModule.Gender=documentSnapshot.getString("gender");
                StaticUserModule.BloodType=documentSnapshot.getString("bloodType");
                StaticUserModule.City=documentSnapshot.getString("city");
                StaticUserModule.lastMedicalChick=documentSnapshot.getString("lastMedicalChick");
                StaticUserModule.lastDonation=documentSnapshot.getString("lastDonation");
                StaticUserModule.Virusc=documentSnapshot.getBoolean("virusc");
                StaticUserModule.others=documentSnapshot.getBoolean("others");
                StaticUserModule.Dentist=(documentSnapshot.getBoolean("dentist"));
                StaticUserModule.Operation=documentSnapshot.getBoolean("operation");
                StaticUserModule.medicalAvailability=documentSnapshot.getBoolean("medicalAvailability");


            }
        });
    }
    static public void Update(){
        UserModule module=new UserModule(StaticUserModule.UserName, StaticUserModule.Password,StaticUserModule.DateofBirth,
                StaticUserModule.MobileNumber,StaticUserModule.Gender,StaticUserModule.BloodType,
                StaticUserModule.City,StaticUserModule.lastMedicalChick,StaticUserModule.lastDonation,
                StaticUserModule.location,StaticUserModule.Dentist,StaticUserModule.Virusc,StaticUserModule.others,
                StaticUserModule.Operation,StaticUserModule.medicalAvailability);
        try {
            db_collection.document(StaticUserModule.id).set(module).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Log.i("Add Data","Added");
                    added=true;
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.d("Add Data","Error "+e);
                    added=false;
                }
            });
        }catch (Exception e){
            Log.i("Error ",e.toString());
        }
    }
    //////////////////////////////////////////////////////////
    static public boolean RequestAddToDataBase(){
        RequestModule module=new RequestModule(StaticRequestModule.age,StaticRequestModule.area,
                StaticRequestModule.bloodbags,StaticRequestModule.city,StaticRequestModule.date,
                StaticRequestModule.gender,StaticRequestModule.hospital,StaticRequestModule.mobileNumber,
                StaticRequestModule.name,StaticRequestModule.number0fBB);
        try {
            db_collection2.document(StaticRequestModule.mobileNumber).set(module).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Log.i("Add Data","Added");
                    NewRequestAdded=true;
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.d("Add Data","Error "+e);
                    NewRequestAdded=false;
                }
            });
        }catch (Exception e){
            Log.i("Error ",e.toString());
        }
        return NewRequestAdded;
    }
    static public void getRequest(){
        if (StaticUserModule.BloodType.equals("dontKnow"))
            x="Any";
        else
            x=StaticUserModule.BloodType;
        db_collection2.whereEqualTo("city",StaticUserModule.City)
                .whereEqualTo("bloodBags",x)
                .get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        for(QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots){
                            if (documentSnapshot.getId().equals(StaticUserModule.MobileNumber)||documentSnapshot.getId().equals(StaticRequestModule.SkipedmobileNumber)
                            ||documentSnapshot.getString("numberOfBB").equals("0"))
                                continue;
                            else
                                StaticRequestModule.mobileNumber=(documentSnapshot.getId());
                        }LoadReuest();

                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });


    }
    static public void getRequest2(){
        db_collection2.whereEqualTo("city",StaticUserModule.City)
                .whereEqualTo("bloodBags","Any")
                .get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        for(QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots){
                            if (documentSnapshot.getId().equals(StaticUserModule.MobileNumber)||documentSnapshot.getId().equals(StaticRequestModule.SkipedmobileNumber)
                                    ||documentSnapshot.getString("numberOfBB").equals("0"))
                                continue;
                            else
                                StaticRequestModule.mobileNumber=(documentSnapshot.getId());
                        }LoadData1();

                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });


    }
    static public void LoadReuest(){
        db_collection2.document(StaticRequestModule.mobileNumber).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                // UserModule note=documentSnapshot.toObject(UserModule.class);
                StaticRequestModule.name=documentSnapshot.getString("name");
                StaticRequestModule.age=documentSnapshot.getString("age");
                StaticRequestModule.bloodbags=documentSnapshot.getString("bloodBags");
                StaticRequestModule.city=documentSnapshot.getString("city");
                StaticRequestModule.hospital=documentSnapshot.getString("hospital");
                StaticRequestModule.date=documentSnapshot.getString("date");
                StaticRequestModule.gender=documentSnapshot.getString("gender");
                StaticRequestModule.number0fBB=documentSnapshot.getString("numberOfBB");
                StaticRequestModule.area=documentSnapshot.getString("area");









            }
        });
    }
    static public void updateWhenAcceptRequest(){
       int x=Integer.parseInt(StaticRequestModule.number0fBB)-1;
        StaticRequestModule.number0fBB=""+x;
        RequestModule module=new RequestModule(StaticRequestModule.age,StaticRequestModule.area,
                StaticRequestModule.bloodbags,StaticRequestModule.city,StaticRequestModule.date,
                StaticRequestModule.gender,StaticRequestModule.hospital,StaticRequestModule.mobileNumber,
                StaticRequestModule.name,StaticRequestModule.number0fBB);
        try {
            db_collection2.document(StaticRequestModule.mobileNumber).set(module).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Log.i("Add Data","Added");
                    NewRequestAdded=true;
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.d("Add Data","Error "+e);
                    NewRequestAdded=false;
                }
            });
        }catch (Exception e){
            Log.i("Error ",e.toString());
        }




    }
    static public void updateWhenCanceltRequest(){
        int x=Integer.parseInt(StaticRequestModule.number0fBB)+1;
        StaticRequestModule.number0fBB=""+x;
        RequestModule module=new RequestModule(StaticRequestModule.age,StaticRequestModule.area,
                StaticRequestModule.bloodbags,StaticRequestModule.city,StaticRequestModule.date,
                StaticRequestModule.gender,StaticRequestModule.hospital,StaticRequestModule.mobileNumber,
                StaticRequestModule.name,StaticRequestModule.number0fBB);
        try {
            db_collection2.document(StaticRequestModule.mobileNumber).set(module).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Log.i("Add Data","Added");
                    NewRequestAdded=true;
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.d("Add Data","Error "+e);
                    NewRequestAdded=false;
                }
            });
        }catch (Exception e){
            Log.i("Error ",e.toString());
        }




    }
    /////////////////////////////////////////////////////////
    static public boolean RequestInfoAddToDataBase(){
        RequestInfoModule requestInfoModule=new RequestInfoModule();
        try {
            db_collection3.document(StaticRequestModule.mobileNumber).set(requestInfoModule).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Log.i("Add Data","Added");
                    NewRequestAdded=true;
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.d("Add Data","Error "+e);
                    NewRequestAdded=false;
                }
            });
        }catch (Exception e){
            Log.i("Error ",e.toString());
        }
        return NewRequestAdded;
    }
    static public void AddAcceptance(String name, String phoneNumber, String City){
        HashMap<String, Object> result = new HashMap<>();
        if (StaticRequestModule.oldnumber0fBB.equals("8")){
            result.put("donor8PhoneNumber",phoneNumber);
            result.put("donor8Name",name);
            result.put("donor8City",City);
            db_collection3.document(StaticRequestModule.mobileNumber)
                        .update(result);

        }
        else if (StaticRequestModule.oldnumber0fBB.equals("7")){
            result.put("donor7PhoneNumber",phoneNumber);
            result.put("donor7Name",name);
            result.put("donor7City",City);
            db_collection3.document(StaticRequestModule.mobileNumber)
                    .update(result);
        }
        else if (StaticRequestModule.oldnumber0fBB.equals("6")){
            result.put("donor6PhoneNumber",phoneNumber);
            result.put("donor6Name",name);
            result.put("donor6City",City);
            db_collection3.document(StaticRequestModule.mobileNumber)
                    .update(result);
        }
        else if (StaticRequestModule.oldnumber0fBB.equals("5")){
            result.put("donor5PhoneNumber",phoneNumber);
            result.put("donor5Name",name);
            result.put("donor5City",City);
            db_collection3.document(StaticRequestModule.mobileNumber)
                    .update(result);}
        else if (StaticRequestModule.oldnumber0fBB.equals("4")){
            result.put("donor4PhoneNumber",phoneNumber);
            result.put("donor4Name",name);
            result.put("donor4City",City);
            db_collection3.document(StaticRequestModule.mobileNumber)
                    .update(result);}
        else if (StaticRequestModule.oldnumber0fBB.equals("3")){
            result.put("donor3PhoneNumber",phoneNumber);
            result.put("donor3Name",name);
            result.put("donor3City",City);
            db_collection3.document(StaticRequestModule.mobileNumber)
                    .update(result);}
        else if (StaticRequestModule.oldnumber0fBB.equals("2")){
            result.put("donor2PhoneNumber",phoneNumber);
            result.put("donor2Name",name);
            result.put("donor2City",City);
            db_collection3.document(StaticRequestModule.mobileNumber)
                    .update(result);}
        else if (StaticRequestModule.oldnumber0fBB.equals("1")){
            result.put("donor1PhoneNumber",phoneNumber);
            result.put("donor1Name",name);
            result.put("donor1City",City);
            db_collection3.document(StaticRequestModule.mobileNumber)
                    .update(result);}

    }
    static public void LoadReuestInfo(){
        db_collection3.document(StaticRequestModule.mobileNumber).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                StaticRequestInfoModule.donor8Name=documentSnapshot.getString("donor8Name");
                StaticRequestInfoModule.donor8PhoneNumber=documentSnapshot.getString("donor8PhoneNumber");
                StaticRequestInfoModule.donor8City=documentSnapshot.getString("donor8City");
                StaticRequestInfoModule.donor7Name=documentSnapshot.getString("donor7Name");
                StaticRequestInfoModule.donor7PhoneNumber=documentSnapshot.getString("donor7PhoneNumber");
                StaticRequestInfoModule.donor7City=documentSnapshot.getString("donor7City");
                StaticRequestInfoModule.donor6Name=documentSnapshot.getString("donor6Name");
                StaticRequestInfoModule.donor6PhoneNumber=documentSnapshot.getString("donor6PhoneNumber");
                StaticRequestInfoModule.donor6City=documentSnapshot.getString("donor6City");
                StaticRequestInfoModule.donor5Name=documentSnapshot.getString("donor5Name");
                StaticRequestInfoModule.donor5PhoneNumber=documentSnapshot.getString("donor5PhoneNumber");
                StaticRequestInfoModule.donor5City=documentSnapshot.getString("donor5City");
                StaticRequestInfoModule.donor4Name=documentSnapshot.getString("donor4Name");
                StaticRequestInfoModule.donor4PhoneNumber=documentSnapshot.getString("donor4PhoneNumber");
                StaticRequestInfoModule.donor4City=documentSnapshot.getString("donor4City");
                StaticRequestInfoModule.donor3Name=documentSnapshot.getString("donor3Name");
                StaticRequestInfoModule.donor3PhoneNumber=documentSnapshot.getString("donor3PhoneNumber");
                StaticRequestInfoModule.donor3City=documentSnapshot.getString("donor3City");
                StaticRequestInfoModule.donor2Name=documentSnapshot.getString("donor2Name");
                StaticRequestInfoModule.donor2PhoneNumber=documentSnapshot.getString("donor2PhoneNumber");
                StaticRequestInfoModule.donor2City=documentSnapshot.getString("donor2City");
                StaticRequestInfoModule.donor1Name=documentSnapshot.getString("donor1Name");
                StaticRequestInfoModule.donor1PhoneNumber=documentSnapshot.getString("donor1PhoneNumber");
                StaticRequestInfoModule.donor1City=documentSnapshot.getString("donor1City");











            }
        });
    }
    static public void AddAcceptanceForRequester(String name, String phoneNumber, String City,int DonorNum){
        HashMap<String, Object> result = new HashMap<>();
        if (DonorNum==8){
            result.put("donor8PhoneNumber",phoneNumber);
            result.put("donor8Name",name);
            result.put("donor8City",City);
            db_collection3.document(StaticRequestModule.mobileNumber)
                    .update(result);
        }
        else if (DonorNum==7){
            result.put("donor7PhoneNumber",phoneNumber);
            result.put("donor7Name",name);
            result.put("donor7City",City);
            db_collection3.document(StaticRequestModule.mobileNumber)
                    .update(result);
        }
        else if (DonorNum==6){
            result.put("donor6PhoneNumber",phoneNumber);
            result.put("donor6Name",name);
            result.put("donor6City",City);
            db_collection3.document(StaticRequestModule.mobileNumber)
                    .update(result);
        }
        else if (DonorNum==5){
            result.put("donor5PhoneNumber",phoneNumber);
            result.put("donor5Name",name);
            result.put("donor5City",City);
            db_collection3.document(StaticRequestModule.mobileNumber)
                    .update(result);}
        else if (DonorNum==4){
            result.put("donor4PhoneNumber",phoneNumber);
            result.put("donor4Name",name);
            result.put("donor4City",City);
            db_collection3.document(StaticRequestModule.mobileNumber)
                    .update(result);}
        else if (DonorNum==3){
            result.put("donor3PhoneNumber",phoneNumber);
            result.put("donor3Name",name);
            result.put("donor3City",City);
            db_collection3.document(StaticRequestModule.mobileNumber)
                    .update(result);}
        else if (DonorNum==2){
            result.put("donor2PhoneNumber",phoneNumber);
            result.put("donor2Name",name);
            result.put("donor2City",City);
            db_collection3.document(StaticRequestModule.mobileNumber)
                    .update(result);}
        else if (DonorNum==1){
            result.put("donor1PhoneNumber",phoneNumber);
            result.put("donor1Name",name);
            result.put("donor1City",City);
            db_collection3.document(StaticRequestModule.mobileNumber)
                    .update(result);}

    }
    static public boolean DonationCanceld(){
        db_collection3.document(StaticRequestModule.mobileNumber)
                .get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        FireBaseFunctions.canceled=false;
                    } else {
                        FireBaseFunctions.canceled=true;
                    }
                } else {
                    FireBaseFunctions.canceled=true;
                }
            }
        });
        return FireBaseFunctions.canceled; }
    /////////////////////////////////////////////////////////
    static public boolean EndRequest(){
        db_collection3.document(StaticRequestModule.mobileNumber).delete();
        db_collection2.document(StaticRequestModule.mobileNumber).delete();
        RequestModule module=new RequestModule(StaticRequestModule.age,StaticRequestModule.area,
                StaticRequestModule.bloodbags,StaticRequestModule.city,StaticRequestModule.date,
                StaticRequestModule.gender,StaticRequestModule.hospital,StaticRequestModule.mobileNumber,
                StaticRequestModule.name,StaticRequestModule.oldnumber0fBB);
        try {
            db_collection4.document(StaticRequestModule.mobileNumber).set(module).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Log.i("Add Data","Added");
                    NewRequestAdded=true;
                    StaticRequestModule.mobileNumber="0";
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.d("Add Data","Error "+e);
                    NewRequestAdded=false;
                }
            });
        }catch (Exception e){
            Log.i("Error ",e.toString());
        }
        return NewRequestAdded;
    }
    static public void CanceleRequest(){
        db_collection3.document(StaticRequestModule.mobileNumber).delete();
        db_collection2.document(StaticRequestModule.mobileNumber).delete();
        StaticRequestModule.mobileNumber="0";
    }
    static public boolean DoneDonation(){
            db_collection4.document(StaticRequestModule.mobileNumber)
            .get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                          FireBaseFunctions.result=true;
                        } else {
                            FireBaseFunctions.result=false;
                        }
                    } else {
                        FireBaseFunctions.result=false;
                    }
                }
            });
   return FireBaseFunctions.result; }






}

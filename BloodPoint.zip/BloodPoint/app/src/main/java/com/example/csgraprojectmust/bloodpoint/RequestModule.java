package com.example.csgraprojectmust.bloodpoint;

public class RequestModule {
    private String age,area,bloodBags,city,date,gender,hospital,mobileNumber,name,numberOfBB;

    public RequestModule(String age, String area, String bloodBags, String city, String date, String gender,
                         String hospital, String mobileNumber, String name, String number0fBB) {
        this.age = age;
        this.area = area;
        this.bloodBags = bloodBags;
        this.city = city;
        this.date = date;
        this.gender = gender;
        this.hospital = hospital;
        this.mobileNumber = mobileNumber;
        this.name = name;
        this.numberOfBB = number0fBB;
    }

    public String getAge() {
        return age;
    }

    public String getArea() {
        return area;
    }

    public String getBloodBags() {
        return bloodBags;
    }

    public String getCity() {
        return city;
    }

    public String getDate() {
        return date;
    }

    public String getGender() {
        return gender;
    }

    public String getHospital() {
        return hospital;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public String getName() {
        return name;
    }

    public String getNumberOfBB() {
        return numberOfBB;
    }
}

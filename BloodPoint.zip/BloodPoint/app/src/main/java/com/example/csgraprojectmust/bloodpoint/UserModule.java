package com.example.csgraprojectmust.bloodpoint;

public class UserModule {
    private     String UserName="",Password="",DateofBirth="",
            MobileNumber="",Gender="",BloodType="",City="",lastMedicalChick=""
            ,lastDonation="",location="";
        private   Boolean  Dentist=false,Virusc=false,others=false,Operation=false,medicalAvailability=true;

    public String getUserName() {
        return UserName;
    }

    public String getPassword() {
        return Password;
    }

    public String getDateofBirth() {
        return DateofBirth;
    }

    public String getMobileNumber() {
        return MobileNumber;
    }

    public String getGender() {
        return Gender;
    }

    public String getBloodType() {
        return BloodType;
    }

    public String getCity() {
        return City;
    }

    public String getLastMedicalChick() {
        return lastMedicalChick;
    }

    public String getLastDonation() {
        return lastDonation;
    }

    public Boolean getMedicalAvailability() {
        return medicalAvailability;
    }

    public String getLocation() {
        return location;
    }

    public Boolean getDentist() {
        return Dentist;
    }

    public Boolean getVirusc() {
        return Virusc;
    }

    public Boolean getOthers() {
        return others;
    }

    public Boolean getOperation() {
        return Operation;
    }

    public UserModule(String userName, String password, String dateofBirth,
                      String mobileNumber, String gender, String bloodType,
                      String city, String lastMedicalChick, String lastDonation,
                      String location, Boolean dentist, Boolean virusc, Boolean others, Boolean
                              operation,Boolean medicalAvailability) {
        UserName = userName;
        Password = password;
        DateofBirth = dateofBirth;
        MobileNumber = mobileNumber;
        Gender = gender;
        BloodType = bloodType;
        City = city;
        this.lastMedicalChick = lastMedicalChick;
        this.lastDonation = lastDonation;
        this.location = location;
        Dentist = dentist;
        Virusc = virusc;
        this.others = others;
        Operation = operation;
        this.medicalAvailability=medicalAvailability;
    }
}

package com.example.csgraprojectmust.bloodpoint;


import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;


import java.util.Calendar;
import java.util.regex.Pattern;
public class SignUp extends AppCompatActivity{


    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    "(?=.*[a-zA-Z])" +      //any letter
                    "(?=\\S+$)" +           //no white spaces
                    ".{8,}" +               //at least 4 characters
                    "$");

    private TextInputLayout textInputName;
    private TextInputLayout textInputPhone;
    private TextInputLayout textInputPassword;
    private TextInputLayout textInputConfirmPassword;
    private TextView txt_Pickdate;
    private Spinner spinnerblood,spinnercity;
    private Calendar calendar;
    private DatePickerDialog datpicker;
    private String dateofBirth="0",Gender="0";
    private RadioGroup GenderRadio;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        textInputName = findViewById(R.id.text_input_name);
        textInputPhone = findViewById(R.id.text_input_phone);
        textInputPassword = findViewById(R.id.text_input_pass);
        textInputConfirmPassword = findViewById(R.id.text_input_confirmpass);
        txt_Pickdate=findViewById(R.id.txt_Pickdate);
         spinnerblood = findViewById(R.id.Spinnerblood);
         GenderRadio =(RadioGroup)findViewById(R.id.gender);
        ArrayAdapter<CharSequence> adapterblood = ArrayAdapter.createFromResource(this,
        R.array.bloodgroup, android.R.layout.simple_spinner_item);
        adapterblood.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerblood.setAdapter(adapterblood);
         spinnercity = findViewById(R.id.city);
        ArrayAdapter<CharSequence> adaptercity = ArrayAdapter.createFromResource(this,
        R.array.Citys, android.R.layout.simple_spinner_item);
        adaptercity.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnercity.setAdapter(adaptercity);
        calendar=Calendar.getInstance();
        txt_Pickdate.setText(calendar.get(Calendar.DAY_OF_MONTH)+"/"+calendar.get(Calendar.MONTH)+"/"+calendar.get(Calendar.YEAR));
        spinnerblood.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i){
                    case 0:
                        StaticUserModule.BloodType="dontKnow";
                        break;
                    case 1:
                        StaticUserModule.BloodType="A+";
                        break;
                    case 2:
                        StaticUserModule.BloodType="A-";
                        break;
                    case 3:
                        StaticUserModule.BloodType="B+";
                        break;
                    case 4:
                        StaticUserModule.BloodType="B-";
                        break;
                    case 5:
                        StaticUserModule.BloodType="O+";
                        break;
                    case 6:
                        StaticUserModule.BloodType="O-";
                        break;
                    case 7:
                        StaticUserModule.BloodType="AB+";
                        break;
                    case 8:
                        StaticUserModule.BloodType="AB-";
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spinnercity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
               switch (i)
                {
                    case 0:
                        StaticUserModule.City="Cairo";
                        break;
                    case 1:
                        StaticUserModule.City="Giza";
                        break;
                    case 2:
                        StaticUserModule.City="Sharqia";
                        break;
                    case 3:
                        StaticUserModule.City="Dakahlia";
                        break;
                    case 4:
                        StaticUserModule.City="Behira";
                        break;
                    case 5:
                        StaticUserModule.City="Minya";
                        break;
                    case 6:
                        StaticUserModule.City="Qalyubia";
                        break;
                    case 7:
                        StaticUserModule.City=("Alexandria");
                        break;
                    case 8:
                        StaticUserModule.City=("Gharbia");
                        break;
                    case 9:
                        StaticUserModule.City=("Sohag");
                        break;
                    case 11:
                        StaticUserModule.City=("Asyut");
                        break;
                    case 12:
                        StaticUserModule.City=("Mnoufia");
                        break;
                    case 13:
                        StaticUserModule.City=("Kafr El Shekikh");
                        break;
                    case 14:
                        StaticUserModule.City=("Fayium");
                        break;
                    case 15:
                        StaticUserModule.City=("Quena");
                        break;
                    case 16:
                        StaticUserModule.City=("BeniSuef");
                        break;
                    case 17:
                        StaticUserModule.City=("Aswan");
                        break;
                    case 18:
                        StaticUserModule.City=("Dasmietta");
                        break;
                    case 19:
                        StaticUserModule.City=("Ismailia");
                        break;
                    case 20:
                        StaticUserModule.City=("Luxor");
                        break;
                    case 21:
                        StaticUserModule.City=("PortSaid");
                        break;
                    case 22:
                        StaticUserModule.City=("Suez");
                        break;
                    case 23:
                        StaticUserModule.City=("Matrouh");
                        break;
                    case 24:
                        StaticUserModule.City=("NorthSini");
                        break;
                    case 25:
                        StaticUserModule.City=("SouthSini");
                        break;
                    case 26:
                        StaticUserModule.City=("RedSea");
                        break;
                    case 27:
                        StaticUserModule.City=("NewValue");
                        break;



                }}

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        GenderRadio.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        switch (i){
            case R.id.Male:
                Gender="Male";
                break;
            case R.id.Female:
                Gender="Female";
                break;
        }
    }
});
    }

    private boolean validateUsername() {
        String usernameInput = textInputName.getEditText().getText().toString().trim();

        if (usernameInput.isEmpty()) {
            textInputName.setError("Field can't be empty");
            return false;
        } else if (usernameInput.length() > 30) {
            textInputName.setError("Username too long");
            return false;
        } else {
            textInputName.setError(null);
            return true;
        }
    }

    private boolean validatePhone() {
        String phoneInput = textInputPhone.getEditText().getText().toString().trim();

        if (phoneInput.isEmpty()) {
            textInputPhone.setError("Field can't be empty");
            return false;
        } else if (phoneInput.length() != 11) {
            textInputPhone.setError("Number is wrong");
            return false;
        } else {
            textInputPhone.setError(null);
            return true;
        }
    }

    private boolean validatePassword() {
        String passwordInput = textInputPassword.getEditText().getText().toString().trim();
        String confirmpasswordInput = textInputConfirmPassword.getEditText().getText().toString().trim();
        if (passwordInput.isEmpty()) {
            textInputPassword.setError("Field can't be empty");
            return false;
        } else if (!PASSWORD_PATTERN.matcher(passwordInput).matches()) {
            textInputPassword.setError("Password must contain letters and over 8 letters ");
            return false;
        } else if (passwordInput.length() > 16) {
            textInputPassword.setError("Password is too long");
            return false;
        }
        else if(confirmpasswordInput.isEmpty()) {
            textInputConfirmPassword.setError("Field can't be empty");
            return false;}
        else if(!confirmpasswordInput.equals(passwordInput)){
            textInputConfirmPassword.setError("No mach");
                return false;
        }
        else {
            textInputPassword.setError(null);
            textInputConfirmPassword.setError(null);
            return true;
        }
    }

    public void confirm(View v) {
        if (!validateUsername() | !validatePhone() | !validatePassword()) {
            return;
        }
        if (dateofBirth=="0")
        { Toast.makeText(this,"choose date of birth",Toast.LENGTH_SHORT).show();
        return;}
        if (Gender=="0"){
            Toast.makeText(this,"Choose your Gender",Toast.LENGTH_SHORT).show();
        return;}
        StaticUserModule.UserName=textInputName.getEditText().getText().toString();
        StaticUserModule.Password=textInputPassword.getEditText().getText().toString();
        StaticUserModule.MobileNumber="+20"+textInputPhone.getEditText().getText().toString();
        StaticUserModule.DateofBirth=dateofBirth;
        StaticUserModule.Gender=Gender;
        Intent accountVerification=new Intent(this,AccountVerification.class);
        startActivity(accountVerification);

    }

    public void pickDate(View view) {
        datpicker = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                txt_Pickdate.setText(i2+"/"+((i1)++)+"/"+i);
                dateofBirth=i2+"/"+((i1)++)+"/"+i;

            }
        },calendar.get(calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH));
        datpicker.show();

    }
}
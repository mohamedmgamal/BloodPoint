package com.example.csgraprojectmust.bloodpoint;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class AccountVerification extends AppCompatActivity {
EditText confirmationMassage;
    private FirebaseAuth auth=FirebaseAuth.getInstance();
    String verficationCode,Enterdverficationnumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_verification);
        confirmationMassage=(EditText)findViewById(R.id.txt_confirmationMassage);
        sendverficationcode();
    }
    public void Resend(View view) {
        sendverficationcode();
        Toast.makeText(this,"Code resend",Toast.LENGTH_SHORT).show();
    }

    public void confirm(View view) {
        Enterdverficationnumber=confirmationMassage.getText().toString();
        if (Enterdverficationnumber.isEmpty())
        {Toast.makeText(this,"This field cant be empty",Toast.LENGTH_SHORT).show();
            return;
        }
        verifyCode();
    }

    private void sendverficationcode(){
         PhoneAuthProvider.getInstance().verifyPhoneNumber(
                 StaticUserModule.MobileNumber,        // Phone number to verify
                 60,                 // Timeout duration
                 TimeUnit.SECONDS,   // Unit of timeout
                 this,               // Activity (for callback binding)
                 mCallbacks);        // OnVerificationStateChangedCallbacks }

    }
    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks=new PhoneAuthProvider.OnVerificationStateChangedCallbacks()  {
        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {

        }
        @Override
        public void onVerificationFailed(FirebaseException e) {
Toast.makeText(AccountVerification.this,"Error "+e,Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
            verficationCode=s;
            Toast.makeText(AccountVerification.this,"Code : "+verficationCode,Toast.LENGTH_LONG).show();
        }
    };
    private void verifyCode(){
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verficationCode, Enterdverficationnumber);
   SignInWithCredential(credential);
    }
    private void SignInWithCredential(PhoneAuthCredential credential) {
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                          Intent intent=new Intent(AccountVerification.this,medical1_Activity.class);
                          startActivity(intent);

                            // ...
                        } else {
                            // Sign in failed, display a message and update the UI
                            Toast.makeText(AccountVerification.this,"Wrong Verification Code ",Toast.LENGTH_LONG).show();
                                // The verification code entered was invalid


                        }
                    }
                });
    }

}

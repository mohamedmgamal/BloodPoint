package com.example.csgraprojectmust.bloodpoint;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class SplashScreen extends AppCompatActivity {
   Thread thread;int  returnVal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splashscreen);
      thread =new Thread(){
            @Override
            public void run() {
                try {
                    sleep(1000);
                    ChickConnection();

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };thread.start();
    }
    private void ChickConnection(){
        if(isNetworkAvailable()&&isOnline()==0)
        {if (fileExists())
        { Retrieve();
            Intent Home = new Intent(this, Home.class);
            startActivity(Home);
            finish();}
        else {
            Intent Login = new Intent(this, LogIn.class);
            startActivity(Login);
            finish();
        }}else
        {
            Snackbar snackbar=Snackbar.make(findViewById(R.id.LauncherLayout),"No internet Connection",Snackbar.LENGTH_INDEFINITE)
                    .setAction("Retry", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            ChickConnection();
                        }
                    });snackbar.show();
        } }
    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
    private int isOnline() {
        try {
            Process p1 = java.lang.Runtime.getRuntime().exec("ping -c 1 www.google.com");
              returnVal = p1.waitFor();
           // Toast.makeText(this,""+returnVal,Toast.LENGTH_LONG).show();
            return returnVal;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return 0;


    }
    public boolean fileExists() {
        FileInputStream fis = null;
        try {
            fis = openFileInput("user");
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text="0";
            while ((text = br.readLine()) != null) {
                sb.append(text).append("\n");
            }
            if (text=="0")
                return false;
            else
                return true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }    }}return false;}
    public void Retrieve()  {
        FileInputStream fis = null;
        try {
            fis = openFileInput("user");
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text;
            while ((text = br.readLine()) != null) {
                String[] words = text.split("//");
                StaticUserModule.id=words[0];
                        StaticUserModule.UserName=words[1];
                        StaticUserModule.MobileNumber=words[2];
                        StaticUserModule.BloodType=words[3];
                        StaticUserModule.medicalAvailability=Boolean.valueOf(words[4]);
                        StaticUserModule.lastMedicalChick=words[5];
                        StaticUserModule.lastDonation+=words[6];
                        StaticUserModule.Virusc= Boolean.valueOf(words[7]);
                        StaticUserModule.Dentist= Boolean.valueOf(words[8]);
                        StaticUserModule.Operation= Boolean.parseBoolean(words[9]);
                        StaticUserModule.others= Boolean.valueOf(words[10]);
                        StaticUserModule.Gender=words[11];
                        StaticUserModule.DateofBirth=words[12];
                        StaticUserModule.City=words[13];
            }



        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }    }}}

}

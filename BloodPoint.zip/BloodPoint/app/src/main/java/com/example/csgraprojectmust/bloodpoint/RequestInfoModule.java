package com.example.csgraprojectmust.bloodpoint;

public class RequestInfoModule {
    String donor1City="0",donor1Name="0",donor1PhoneNumber="0",
            donor2City="0",donor2Name="0",donor2PhoneNumber="0",
            donor3City="0",donor3Name="0",donor3PhoneNumber="0",
            donor4City="0",donor4Name="0",donor4PhoneNumber="0",
            donor5City="0",donor5Name="0",donor5PhoneNumber="0",
            donor6City="0",donor6Name="0",donor6PhoneNumber="0",
            donor7City="0",donor7Name="0",donor7PhoneNumber="0",
            donor8City="0",donor8Name="0",donor8PhoneNumber="0";

    public String getdonor1City() {
        return donor1City;
    }

    public String getdonor1Name() {
        return donor1Name;
    }

    public String getdonor1PhoneNumber() {
        return donor1PhoneNumber;
    }

    public String getdonor2City() {
        return donor2City;
    }

    public String getdonor2Name() {
        return donor2Name;
    }

    public String getdonor2PhoneNumber() {
        return donor2PhoneNumber;
    }

    public String getdonor3City() {
        return donor3City;
    }

    public String getdonor3Name() {
        return donor3Name;
    }

    public String getdonor3PhoneNumber() {
        return donor3PhoneNumber;
    }

    public String getdonor4City() {
        return donor4City;
    }

    public String getdonor4Name() {
        return donor4Name;
    }

    public String getdonor4PhoneNumber() {
        return donor4PhoneNumber;
    }

    public String getdonor5City() {
        return donor5City;
    }

    public String getdonor5Name() {
        return donor5Name;
    }

    public String getdonor5PhoneNumber() {
        return donor5PhoneNumber;
    }

    public String getdonor6City() {
        return donor6City;
    }

    public String getdonor6Name() {
        return donor6Name;
    }

    public String getdonor6PhoneNumber() {
        return donor6PhoneNumber;
    }

    public String getdonor7City() {
        return donor7City;
    }

    public String getdonor7Name() {
        return donor7Name;
    }

    public String getdonor7PhoneNumber() {
        return donor7PhoneNumber;
    }

    public String getdonor8City() {
        return donor8City;
    }

    public String getdonor8Name() {
        return donor8Name;
    }

    public String getdonor8PhoneNumber() {
        return donor8PhoneNumber;
    }

    public void setdonor1City(String donor1City) {
        this.donor1City = donor1City;
    }

    public void setdonor1Name(String donor1Name) {
        this.donor1Name = donor1Name;
    }

    public void setdonor1PhoneNumber(String donor1PhoneNumber) {
        this.donor1PhoneNumber = donor1PhoneNumber;
    }

    public void setdonor2City(String donor2City) {
        this.donor2City = donor2City;
    }

    public void setdonor2Name(String donor2Name) {
        this.donor2Name = donor2Name;
    }

    public void setdonor2PhoneNumber(String donor2PhoneNumber) {
        this.donor2PhoneNumber = donor2PhoneNumber;
    }

    public void setdonor3City(String donor3City) {
        this.donor3City = donor3City;
    }

    public void setdonor3Name(String donor3Name) {
        this.donor3Name = donor3Name;
    }

    public void setdonor3PhoneNumber(String donor3PhoneNumber) {
        this.donor3PhoneNumber = donor3PhoneNumber;
    }

    public void setdonor4City(String donor4City) {
        this.donor4City = donor4City;
    }

    public void setdonor4Name(String donor4Name) {
        this.donor4Name = donor4Name;
    }

    public void setdonor4PhoneNumber(String donor4PhoneNumber) {
        this.donor4PhoneNumber = donor4PhoneNumber;
    }

    public void setdonor5City(String donor5City) {
        this.donor5City = donor5City;
    }

    public void setdonor5Name(String donor5Name) {
        this.donor5Name = donor5Name;
    }

    public void setdonor5PhoneNumber(String donor5PhoneNumber) {
        this.donor5PhoneNumber = donor5PhoneNumber;
    }

    public void setdonor6City(String donor6City) {
        this.donor6City = donor6City;
    }

    public void setdonor6Name(String donor6Name) {
        this.donor6Name = donor6Name;
    }

    public void setdonor6PhoneNumber(String donor6PhoneNumber) {
        this.donor6PhoneNumber = donor6PhoneNumber;
    }

    public void setdonor7City(String donor7City) {
        this.donor7City = donor7City;
    }

    public void setdonor7Name(String donor7Name) {
        this.donor7Name = donor7Name;
    }

    public void setdonor7PhoneNumber(String donor7PhoneNumber) {
        this.donor7PhoneNumber = donor7PhoneNumber;
    }

    public void setdonor8City(String donor8City) {
        this.donor8City = donor8City;
    }

    public void setdonor8Name(String donor8Name) {
        this.donor8Name = donor8Name;
    }

    public void setdonor8PhoneNumber(String donor8PhoneNumber) {
        this.donor8PhoneNumber = donor8PhoneNumber;
    }
}

package com.example.csgraprojectmust.bloodpoint;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class medical1_Activity extends AppCompatActivity {
    Switch switch_operations, switchDentist,switch_VirusC,switch_Others,switch_LastDonations;
TextView txt_LastDonationDate;
    private Calendar calendar;
    private DatePickerDialog datpicker;
    Boolean Dentist=false,Virusc=false,others=false,Operation=false;
    String lastDonation="0",lastMedicalChick="0";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medical1_);
        switch_operations = (Switch) findViewById(R.id.switch_operations);
        switchDentist = (Switch) findViewById(R.id.switchDentist);
        switch_VirusC = (Switch) findViewById(R.id.switch_VirusC);
        switch_Others = (Switch) findViewById(R.id.switch_Others);
        switch_LastDonations = (Switch) findViewById(R.id.switch_LastDonations);
        txt_LastDonationDate=(TextView)findViewById(R.id.txt_LastDonationDate);

    }

    public void pickDate(View view) {
        datpicker = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                txt_LastDonationDate.setText(i2+"/"+(i1+1)+"/"+i);
                lastDonation=i2+"/"+(i1+1)+"/"+i;

            }
        },calendar.get(calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH));
        datpicker.show();

    }

    public void operation(View view) {
        if (switch_operations.isChecked())
            Operation=true;
        else
            Operation=false;

    }

    public void detist(View view) {
        if(switchDentist.isChecked())
            Dentist=true;
        else
            Dentist=false;
    }

    public void Virusc(View view) {
        if (switch_VirusC.isChecked())
            Virusc=true;
        else
            Virusc=false;
    }

    public void others(View view) {
        if (switch_Others.isChecked())
            others=true;
        else
            others=false;
    }

    public void LastDonation(View view) {
        if (switch_LastDonations.isChecked()) {
            txt_LastDonationDate.setVisibility(View.VISIBLE);
            calendar = Calendar.getInstance();
            txt_LastDonationDate.setText(calendar.get(Calendar.DAY_OF_MONTH) + "/" + (calendar.get(Calendar.MONTH)+1) + "/" + calendar.get(Calendar.YEAR));
        }
        else
            txt_LastDonationDate.setVisibility(View.INVISIBLE);
    }

    public void next(View view) {
        calendar=Calendar.getInstance();
        lastMedicalChick=calendar.get(Calendar.DAY_OF_MONTH)+"/"+(calendar.get(Calendar.MONTH)+1)+"/"+calendar.get(Calendar.YEAR);
   StaticUserModule.lastDonation=lastDonation;
   StaticUserModule.lastMedicalChick=(lastMedicalChick);
   StaticUserModule.Operation=(Operation);
   StaticUserModule.Dentist=(Dentist);
   StaticUserModule.others=(others);
   StaticUserModule.Virusc=(Virusc);
   if ((StaticUserModule.others&&StaticUserModule.Operation&&StaticUserModule.Dentist&&StaticUserModule.Virusc&&!(StaticUserModule.lastDonation=="0")))
   { StaticUserModule.medicalAvailability=false;}
   else
       StaticUserModule.medicalAvailability=true;
   FireBaseFunctions.addToDataBase();
   Toast.makeText(this,"New user Added",Toast.LENGTH_LONG).show();
        FireBaseFunctions.getId();
        Intent next=new Intent(this,Home.class);
        startActivity(next);
       finish();}
}

package com.example.csgraprojectmust.bloodpoint;

import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.file.attribute.DosFileAttributes;

public class GetDirictions extends AppCompatActivity {
    private TextView txt_rerecipientNameInReseve,txt_rerecipintPhonenumberInReseve,
            txt_Hospital,txt_City,txt_BloodGroup,txt_Age,txt_Date;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_dirictions);
        txt_rerecipientNameInReseve=findViewById(R.id.txt_rerecipientNameInReseve);
        txt_rerecipintPhonenumberInReseve=findViewById(R.id.txt_rerecipintPhonenumberInReseve);
        txt_Hospital=findViewById(R.id.txt_Hospital);
        txt_City=findViewById(R.id.txt_City);
        txt_BloodGroup=findViewById(R.id.txt_BloodGroupp);
        txt_Age=findViewById(R.id.txt_Age);
        txt_Date=findViewById(R.id.txt_Date);

        txt_rerecipientNameInReseve.setText(StaticRequestModule.name);
        txt_rerecipintPhonenumberInReseve.setText(StaticRequestModule.mobileNumber);
        txt_Hospital.setText(StaticRequestModule.hospital);
        txt_City.setText(StaticRequestModule.city);
        txt_BloodGroup.setText(StaticRequestModule.bloodbags);
        txt_Age.setText(StaticRequestModule.age);
        txt_Date.setText(StaticRequestModule.date);
        boolean x=FireBaseFunctions.DonationCanceld();
        final Handler handler = new Handler();
        final Handler handler2 = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (FireBaseFunctions.DonationCanceld())
                {
                    Toast.makeText(GetDirictions.this,"Donation Canceled",Toast.LENGTH_LONG).show();
                    StaticRequestModule.mobileNumber="0";
                    Home.Switch_Availability.setChecked(true);
                    Home.Availability=true;
                    Home.btn_currentDonation.setVisibility(View.INVISIBLE);
                    Home.RequestMaade=false;
                    handler2.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Intent start=new Intent(GetDirictions.this,Setviece.class);
                            startService(start);
                            finish();

                        }
                    },1000); }
            }
        }, 1000);

    }

    public void getDricitions(View view) {
        Intent intent = new Intent(android.content.Intent.ACTION_VIEW,
                Uri.parse("geo:0,0?q="+ StaticRequestModule.hospital+" Hospital"));
        Home.btn_currentDonation.setVisibility(View.VISIBLE);
        startActivity(intent);
        finish();
    }

    public void cancel(View view) {
        Toast.makeText(this,"Canceling",Toast.LENGTH_SHORT).show();
        FireBaseFunctions.LoadReuest();
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                FireBaseFunctions.updateWhenCanceltRequest();
                FireBaseFunctions.AddAcceptance("0","0","0");
                StaticRequestModule.SkipedmobileNumber=StaticRequestModule.mobileNumber;
                StaticRequestModule.mobileNumber="0";
                Home.Switch_Availability.setChecked(true);
                Home.Availability=true;
                Home.btn_currentDonation.setVisibility(View.INVISIBLE);
                Home.RequestMaade=false;
                Intent start=new Intent(GetDirictions.this,Setviece.class);
                startService(start);
                finish();
            }
        }, 1000);


    }
    public void DoneDonation(View view) {
        if(FireBaseFunctions.DoneDonation())
        {
            Toast.makeText(this,"Donation Done",Toast.LENGTH_LONG).show();
            Home.btn_currentDonation.setVisibility(View.INVISIBLE);
            StaticRequestModule.mobileNumber="0";
            StaticUserModule.medicalAvailability=false;
            finish();

        }
        else
            Toast.makeText(this,"Donation Still in process",Toast.LENGTH_SHORT).show();

    }
}

package com.example.csgraprojectmust.bloodpoint;

import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.view.View;
import android.widget.Toast;

import java.io.IOException;

public class Setviece extends Service {
    NotificationManagerCompat notificationManager;
    Bitmap largeIcon;
    @Override
    public void onCreate(){
          super.onCreate( );
        notificationManager=NotificationManagerCompat.from(this);
    }
    @Override
    public void onDestroy(){
        super.onDestroy( );
    }
    @Override
    public int onStartCommand(Intent intent,int flag, int startId){
       channel2();
       search();
       return START_STICKY;
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    public void channel2() {
        largeIcon = BitmapFactory.decodeResource(getResources(), R.drawable.logo);
        Intent home=new Intent(this,Home.class);
        PendingIntent pendingIntent=PendingIntent.getActivity(this,0,home,0);
        android.app.Notification notification=new NotificationCompat.Builder(this,Notification.Channel_2_id)
                .setSmallIcon(R.drawable.logo)
                .setLargeIcon(largeIcon)
                .setContentTitle("BloodPoint is running")
                .setContentText("You are available for Donation")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setContentIntent(pendingIntent)
                .build();
       // notificationManager.notify(2,notification);
        startForeground(1,notification);
    }
    public void search() {
        FireBaseFunctions.getRequest();
        FireBaseFunctions.getRequest2();
        //Toast.makeText(Setviece.this,StaticRequestModule.mobileNumber+" "+FireBaseFunctions.x,Toast.LENGTH_SHORT).show();
        if (!StaticRequestModule.mobileNumber.equals("0"))
        {Home.Availability=false;
        Home.Switch_Availability.setChecked(false);
            channel1();}
        else if(Home.Availability)
        { final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                search();
            }
        }, 3000);}
    }
    public void channel1() {
        Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        long[] vibrate = { 0, 100, 200, 300 };
        Intent home=new Intent(this,ResiveRequest.class);
        PendingIntent pendingIntent=PendingIntent.getActivity(this,0,home,0);
        android.app.Notification notification=new NotificationCompat.Builder(this,Notification.Channel_1_id)
                .setSmallIcon(R.drawable.logo)
                .setLargeIcon(largeIcon)
                .setContentTitle("New Request")
                .setContentText("You Have New Matched Request")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setVibrate(vibrate)
                .setSound(uri)
                .setContentIntent(pendingIntent)
                .build();
        notificationManager.notify(2,notification);
    }

}

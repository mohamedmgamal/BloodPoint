package com.example.csgraprojectmust.bloodpoint;

public class StaticRequestModule {

    static String age,area,Key,bloodbags,city,date,gender,hospital,mobileNumber="0",name,number0fBB,oldnumber0fBB,SkipedmobileNumber;

}

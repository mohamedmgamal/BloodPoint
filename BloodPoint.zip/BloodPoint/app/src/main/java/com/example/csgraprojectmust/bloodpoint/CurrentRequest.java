package com.example.csgraprojectmust.bloodpoint;

import android.content.Intent;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
public class CurrentRequest extends AppCompatActivity implements View.OnClickListener {
private TextView txt_DateField,txt_numberOfUnits,
        txt_Donor1Name,txt_Donor1City,txt_Donor1PhoneNum,
        txt_Donor2Name,txt_Donor2City,txt_Donor2PhoneNum,
        txt_Donor3Name,txt_Donor3City,txt_Donor3PhoneNum,
        txt_Donor4Name,txt_Donor4City,txt_Donor4PhoneNum,
        txt_Donor5Name,txt_Donor5City,txt_Donor5PhoneNum,
        txt_Donor6Name,txt_Donor6City,txt_Donor6PhoneNum,
        txt_Donor7Name,txt_Donor7City,txt_Donor7PhoneNum,
        txt_Donor8Name,txt_Donor8City,txt_Donor8PhoneNum;
private LinearLayout Layout_Donor1,Layout_Donor2,Layout_Donor3,Layout_Donor4,Layout_Donor5,Layout_Donor6,
        Layout_Donor7,Layout_Donor8;
    SwipeRefreshLayout pullToRefresh;
    Button btn_clee1,btn_clee2,btn_clee3,btn_clee4
           ,btn_clee5,btn_clee6,btn_clee7,btn_clee8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_request);
        txt_DateField=findViewById(R.id.txt_DateField);
        txt_numberOfUnits=findViewById(R.id.txt_numberOfUnits);
        txt_DateField.setText(StaticRequestModule.date);
        txt_numberOfUnits.setText(StaticRequestModule.number0fBB+" Units");
        txt_Donor1Name=findViewById(R.id.txt_Donor1Name);
        txt_Donor1City=findViewById(R.id.txt_Donor1City);

        txt_Donor1PhoneNum=findViewById(R.id. txt_Donor1PhoneNum);
        txt_Donor2Name=findViewById(R.id.txt_Donor2Name);
        txt_Donor2City=findViewById(R.id.txt_Donor2City);
        txt_Donor2PhoneNum=findViewById(R.id. txt_Donor2PhoneNum);

        txt_Donor3Name=findViewById(R.id.txt_Donor3Name);
        txt_Donor3City=findViewById(R.id.txt_Donor3City);
        txt_Donor3PhoneNum=findViewById(R.id. txt_Donor3PhoneNum);

        txt_Donor4Name=findViewById(R.id.txt_Donor4Name);
        txt_Donor4City=findViewById(R.id.txt_Donor4City);
        txt_Donor4PhoneNum=findViewById(R.id. txt_Donor4PhoneNum);

        txt_Donor5Name=findViewById(R.id.txt_Donor5Name);
        txt_Donor5City=findViewById(R.id.txt_Donor5City);
        txt_Donor5PhoneNum=findViewById(R.id. txt_Donor5PhoneNum);

        txt_Donor6Name=findViewById(R.id.txt_Donor6Name);
        txt_Donor6City=findViewById(R.id.txt_Donor6City);
        txt_Donor6PhoneNum=findViewById(R.id. txt_Donor6PhoneNum);

        txt_Donor7Name=findViewById(R.id.txt_Donor7Name);
        txt_Donor7City=findViewById(R.id.txt_Donor7City);
        txt_Donor7PhoneNum=findViewById(R.id. txt_Donor7PhoneNum);

        txt_Donor8Name=findViewById(R.id.txt_Donor8Name);
        txt_Donor8City=findViewById(R.id.txt_Donor8City);
        txt_Donor8PhoneNum=findViewById(R.id. txt_Donor8PhoneNum);

        Layout_Donor1=findViewById(R.id.Layout_Donor1);
        Layout_Donor2=findViewById(R.id.Layout_Donor2);
        Layout_Donor3=findViewById(R.id.Layout_Donor3);
        Layout_Donor4=findViewById(R.id.Layout_Donor4);
        Layout_Donor5=findViewById(R.id.Layout_Donor5);
        Layout_Donor6=findViewById(R.id.Layout_Donor6);
        Layout_Donor7=findViewById(R.id.Layout_Donor7);
        Layout_Donor8=findViewById(R.id.Layout_Donor8);

        pullToRefresh = (SwipeRefreshLayout) findViewById(R.id.pullToRefresh);

        btn_clee1=(Button)findViewById(R.id.btn_cle1);
        btn_clee1.setOnClickListener(this);
        btn_clee2=findViewById(R.id.btn_cle2);
        btn_clee2.setOnClickListener( this);
        btn_clee3=findViewById(R.id.btn_cle3);
        btn_clee3.setOnClickListener(this);
        btn_clee4=findViewById(R.id.btn_cle4);
        btn_clee4.setOnClickListener(this);
        btn_clee5=findViewById(R.id.btn_cle5);
        btn_clee5.setOnClickListener(this);
        btn_clee6=findViewById(R.id.btn_cle6);
        btn_clee6.setOnClickListener(this);
        btn_clee7=findViewById(R.id.btn_cle7);
        btn_clee7.setOnClickListener(this);
        btn_clee8=findViewById(R.id.btn_cle8);
        btn_clee8.setOnClickListener(this);

        Chick();
        pullToRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
               Refresh();
            }
        });


    }

    public void onClick(View v) {
        // Perform action on click
        switch(v.getId()) {
            case R.id.btn_cle1:
            { FireBaseFunctions.AddAcceptanceForRequester("0","0","0",1);
            Refresh();
            break;}
            case R.id.btn_cle2:
            { FireBaseFunctions.AddAcceptanceForRequester("0","0","0",2);
                Refresh();
                break;}
            case R.id.btn_cle3:
            { FireBaseFunctions.AddAcceptanceForRequester("0","0","0",3);
                Refresh();
                break;}
            case R.id.btn_cle4:
            { FireBaseFunctions.AddAcceptanceForRequester("0","0","0",4);
                Refresh();
                break;}
            case R.id.btn_cle5:
            { FireBaseFunctions.AddAcceptanceForRequester("0","0","0",5);
                Refresh();
                break;}
            case R.id.btn_cle6:
            { FireBaseFunctions.AddAcceptanceForRequester("0","0","0",6);
                Refresh();
                break;}
            case R.id.btn_cle7:
            { FireBaseFunctions.AddAcceptanceForRequester("0","0","0",7);
                Refresh();
                break;}
            case R.id.btn_cle8:
            { FireBaseFunctions.AddAcceptanceForRequester("0","0","0",8);
                Refresh();
                break;}

        }}

    private void Chick() {
        if (StaticRequestInfoModule.donor1PhoneNumber.length()>4){
            Layout_Donor1.setVisibility(View.VISIBLE);
            txt_Donor1Name.setText(StaticRequestInfoModule.donor1Name);
            txt_Donor1City.setText(StaticRequestInfoModule.donor1City);
            txt_Donor1PhoneNum.setText(StaticRequestInfoModule.donor1PhoneNumber);

        }
        else {
            Layout_Donor1.setVisibility(View.GONE);
        }

         if (StaticRequestInfoModule.donor2PhoneNumber.length()>4){
            Layout_Donor2.setVisibility(View.VISIBLE);
            txt_Donor2Name.setText(StaticRequestInfoModule.donor2Name);
            txt_Donor2City.setText(StaticRequestInfoModule.donor2City);
            txt_Donor2PhoneNum.setText(StaticRequestInfoModule.donor2PhoneNumber);

        }
         else {
             Layout_Donor2.setVisibility(View.GONE);
         }
          if (StaticRequestInfoModule.donor3PhoneNumber.length()>4){
            Layout_Donor3.setVisibility(View.VISIBLE);
            txt_Donor3Name.setText(StaticRequestInfoModule.donor3Name);
            txt_Donor3City.setText(StaticRequestInfoModule.donor3City);
            txt_Donor3PhoneNum.setText(StaticRequestInfoModule.donor3PhoneNumber);
          }
          else {
              Layout_Donor3.setVisibility(View.GONE);
          }
          if (StaticRequestInfoModule.donor4PhoneNumber.length()>4){
            Layout_Donor4.setVisibility(View.VISIBLE);
            txt_Donor2Name.setText(StaticRequestInfoModule.donor4Name);
            txt_Donor4City.setText(StaticRequestInfoModule.donor4City);
            txt_Donor4PhoneNum.setText(StaticRequestInfoModule.donor4PhoneNumber);
          }
          else {
              Layout_Donor4.setVisibility(View.GONE);
          }
          if (StaticRequestInfoModule.donor5PhoneNumber.length()>4){
            Layout_Donor5.setVisibility(View.VISIBLE);
            txt_Donor5Name.setText(StaticRequestInfoModule.donor5Name);
            txt_Donor5City.setText(StaticRequestInfoModule.donor5City);
            txt_Donor5PhoneNum.setText(StaticRequestInfoModule.donor5PhoneNumber);
          }
          else {
              Layout_Donor5.setVisibility(View.GONE);
          }
          if (StaticRequestInfoModule.donor6PhoneNumber.length()>4){
            Layout_Donor6.setVisibility(View.VISIBLE);
            txt_Donor6Name.setText(StaticRequestInfoModule.donor6Name);
            txt_Donor6City.setText(StaticRequestInfoModule.donor6City);
            txt_Donor6PhoneNum.setText(StaticRequestInfoModule.donor6PhoneNumber);
          }
          else {
              Layout_Donor6.setVisibility(View.GONE);
          }
          if (StaticRequestInfoModule.donor7PhoneNumber.length()>4){
            txt_Donor7Name.setText(StaticRequestInfoModule.donor7Name);
            txt_Donor7City.setText(StaticRequestInfoModule.donor7City);
            txt_Donor7PhoneNum.setText(StaticRequestInfoModule.donor7PhoneNumber);
          }
          else {
              Layout_Donor7.setVisibility(View.GONE);
          }
          if (StaticRequestInfoModule.donor8PhoneNumber.length()>4){
            Layout_Donor8.setVisibility(View.VISIBLE);
            txt_Donor8Name.setText(StaticRequestInfoModule.donor8Name);
            txt_Donor8City.setText(StaticRequestInfoModule.donor8City);
            txt_Donor8PhoneNum.setText(StaticRequestInfoModule.donor8PhoneNumber);
          }
          else {
              Layout_Donor8.setVisibility(View.GONE);
          }

    }

   private void Refresh(){
        FireBaseFunctions.LoadReuestInfo();
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Chick();
                pullToRefresh.setRefreshing(false);
            }
        }, 2000);

    }

    public void DoneRequest(View view) {
        FireBaseFunctions.EndRequest();
        Home.currentRequest=false;
        Home.RequestMaade=false;
        Toast.makeText(this,"Thank you for using Blood Point ",Toast.LENGTH_SHORT).show();
        finish();
    }

    public void CancelRequest(View view) {
        FireBaseFunctions.CanceleRequest();
        Home.currentRequest=false;
        Home.RequestMaade=false;
        finish();


    }
}

package com.example.csgraprojectmust.bloodpoint;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

public class Notification extends Application {
    public static final String Channel_1_id="Get_Request";
    public static final String Channel_2_id="app_Are_Running";
    @Override
    public void onCreate(){
        super.onCreate();
        createNotificatio();
    }

    private void createNotificatio() {
        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
        {
            NotificationChannel channel=new NotificationChannel(
                    Channel_1_id,
                    "You Have New Request",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("BloodPoint is running");
            NotificationChannel channe2=new NotificationChannel(
                    Channel_2_id,
                    "You Have New Request",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channe2.setDescription("You have are available for donation");
            NotificationManager notificationManager=getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
            notificationManager.createNotificationChannel(channe2);
        }
    }


}

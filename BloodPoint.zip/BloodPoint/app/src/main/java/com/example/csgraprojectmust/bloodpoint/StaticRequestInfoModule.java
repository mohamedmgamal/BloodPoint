package com.example.csgraprojectmust.bloodpoint;

public class StaticRequestInfoModule {
    static String donor1City="0",donor1Name="0",donor1PhoneNumber="0",
            donor2City="0",donor2Name="0",donor2PhoneNumber="0",
            donor3City="0",donor3Name="0",donor3PhoneNumber="0",
            donor4City="0",donor4Name="0",donor4PhoneNumber="0",
            donor5City="0",donor5Name="0",donor5PhoneNumber="0",
            donor6City="0",donor6Name="0",donor6PhoneNumber="0",
            donor7City="0",donor7Name="0",donor7PhoneNumber="0",
            donor8City="0",donor8Name="0",donor8PhoneNumber="0";
}

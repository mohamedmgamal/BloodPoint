package com.example.csgraprojectmust.bloodpoint;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.provider.MediaStore;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Calendar;
import java.util.regex.Pattern;

public class Profile extends AppCompatActivity {
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    "(?=.*[a-zA-Z])" +      //any letter
                    "(?=\\S+$)" +           //no white spaces
                    ".{8,}" +               //at least 4 characters
                    "$");

    private TextView textInputName;
    private TextView textInputPhone;
    private TextView txt_Pickdate;
    private Spinner spinnerblood,spinnercity;
    private Calendar calendar;
    private DatePickerDialog datpicker;
    private RadioGroup GenderRadio;
    private RadioButton male, female;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        textInputName = findViewById(R.id.editfullname2);
        textInputPhone = findViewById(R.id.PhoneNum2);
        txt_Pickdate=findViewById(R.id.Pickdate);
        spinnerblood = findViewById(R.id.Spinnerblood);
        spinnercity=findViewById(R.id.city);
        GenderRadio =(RadioGroup)findViewById(R.id.gender);
        textInputName.setText(StaticUserModule.UserName);
        textInputPhone.setText(StaticUserModule.MobileNumber);
        txt_Pickdate.setText(StaticUserModule.DateofBirth);
        ArrayAdapter<CharSequence> adapterblood = ArrayAdapter.createFromResource(this,
                R.array.bloodgroup, android.R.layout.simple_spinner_item);
        adapterblood.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerblood.setAdapter(adapterblood);
        ArrayAdapter<CharSequence> adaptercity = ArrayAdapter.createFromResource(this,
                R.array.Citys, android.R.layout.simple_spinner_item);
        adaptercity.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnercity.setAdapter(adaptercity);
        male=findViewById(R.id.Male);
        female=findViewById(R.id.Female);
        if(StaticUserModule.Gender.equals("Male"))
            male.setChecked(true);
        else
            female.setChecked(true);
        spinnerblood.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i){
                    case 0:
                        StaticUserModule.BloodType="dontKnow";
                        break;
                    case 1:
                        StaticUserModule.BloodType="A+";
                        break;
                    case 2:
                        StaticUserModule.BloodType="A-";
                        break;
                    case 3:
                        StaticUserModule.BloodType="B+";
                        break;
                    case 4:
                        StaticUserModule.BloodType="B-";
                        break;
                    case 5:
                        StaticUserModule.BloodType="O+";
                        break;
                    case 6:
                        StaticUserModule.BloodType="O-";
                        break;
                    case 7:
                        StaticUserModule.BloodType="AB+";
                        break;
                    case 8:
                        StaticUserModule.BloodType="AB-";
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spinnercity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i)
                {
                    case 0:
                        StaticUserModule.City="Cairo";
                        break;
                    case 1:
                        StaticUserModule.City="Giza";
                        break;
                    case 2:
                        StaticUserModule.City="Sharqia";
                        break;
                    case 3:
                        StaticUserModule.City="Dakahlia";
                        break;
                    case 4:
                        StaticUserModule.City="Behira";
                        break;
                    case 5:
                        StaticUserModule.City="Minya";
                        break;
                    case 6:
                        StaticUserModule.City="Qalyubia";
                        break;
                    case 7:
                        StaticUserModule.City=("Alexandria");
                        break;
                    case 8:
                        StaticUserModule.City=("Gharbia");
                        break;
                    case 9:
                        StaticUserModule.City=("Sohag");
                        break;
                    case 11:
                        StaticUserModule.City=("Asyut");
                        break;
                    case 12:
                        StaticUserModule.City=("Mnoufia");
                        break;
                    case 13:
                        StaticUserModule.City=("Kafr El Shekikh");
                        break;
                    case 14:
                        StaticUserModule.City=("Fayium");
                        break;
                    case 15:
                        StaticUserModule.City=("Quena");
                        break;
                    case 16:
                        StaticUserModule.City=("BeniSuef");
                        break;
                    case 17:
                        StaticUserModule.City=("Aswan");
                        break;
                    case 18:
                        StaticUserModule.City=("Dasmietta");
                        break;
                    case 19:
                        StaticUserModule.City=("Ismailia");
                        break;
                    case 20:
                        StaticUserModule.City=("Luxor");
                        break;
                    case 21:
                        StaticUserModule.City=("PortSaid");
                        break;
                    case 22:
                        StaticUserModule.City=("Suez");
                        break;
                    case 23:
                        StaticUserModule.City=("Matrouh");
                        break;
                    case 24:
                        StaticUserModule.City=("NorthSini");
                        break;
                    case 25:
                        StaticUserModule.City=("SouthSini");
                        break;
                    case 26:
                        StaticUserModule.City=("RedSea");
                        break;
                    case 27:
                        StaticUserModule.City=("NewValue");
                        break;



                }}

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    public void Save(View view) {
FireBaseFunctions.Update();
        finish();
    }

}

package com.example.csgraprojectmust.bloodpoint;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class LogIn extends AppCompatActivity {
    private TextInputLayout textInputPhone;
    private TextInputLayout textInputPassword;
    private ProgressBar PB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        textInputPhone = findViewById(R.id.text_input_phone);
        textInputPassword = findViewById(R.id.text_input_password);
        PB=(ProgressBar)findViewById(R.id.progressBar);
    }

    private boolean validatePhone(){
        String phoneInput = textInputPhone.getEditText().getText().toString().trim();

        if (phoneInput.isEmpty()){
            textInputPhone.setError("Field can't be empty");
            return false;
        } else if (phoneInput.length() != 11){
            textInputPhone.setError("Wrong phone number");
            return false;

        }
        else {
            textInputPhone.setError(null);
            //textInputPhone.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validatePassword(){
        String passwordInput = textInputPassword.getEditText().getText().toString().trim();

        if (passwordInput.isEmpty()){
            textInputPassword.setError("Field can't be empty");
            return false;
        }else {
            textInputPassword.setError(null);
            //textInputPhone.setErrorEnabled(false);
            return true;
        }
    }

    public void confirmInput(View v){
        if(!validatePhone() | !validatePassword()){
           return;
        }
        StaticUserModule.MobileNumber="+20"+textInputPhone.getEditText().getText().toString();
        StaticUserModule.Password=textInputPassword.getEditText().getText().toString();
      FireBaseFunctions.getId();
      PB.setVisibility(View.VISIBLE);
      final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!(StaticUserModule.id=="0"))
                {
                    FireBaseFunctions.LoadData1();
                   Toast.makeText(LogIn.this,"User found and retrieving Data",Toast.LENGTH_LONG).show();
                   final Handler handler1=new Handler();
                   handler.postDelayed(new Runnable() {
                       @Override
                       public void run() {
                           PB.setVisibility(View.GONE);
                           try {
                               save();
                           } catch (IOException e) {
                               e.printStackTrace();
                           }
                           Intent Home = new Intent(LogIn.this,Home.class);
                           startActivity(Home);
                           finish();
                       }
                   },2000);
              }
                else {
                    PB.setVisibility(View.GONE);
                    Toast.makeText(LogIn.this, "Phone Number or password doesn't mach " , Toast.LENGTH_SHORT).show();
                }
            }
        }, 3000);

    }

    public void ForgetPassword(View view) {
        FireBaseFunctions.LoadData1();
        Toast.makeText(this,"Forget Password "+StaticUserModule.UserName,Toast.LENGTH_SHORT).show();
    }

    public void regester(View view) {
        Intent regester=new Intent(this,SignUp.class);
        startActivity(regester);
    }
    public void save() throws IOException {
        String text=StaticUserModule.id+"//"+
                StaticUserModule.UserName+"//"+
                StaticUserModule.MobileNumber+"//"+
                StaticUserModule.BloodType+"//"+
                StaticUserModule.medicalAvailability+"//"+
                StaticUserModule.lastMedicalChick+"//"+
                StaticUserModule.lastDonation+"//"+
                StaticUserModule.Virusc+"//"+
                StaticUserModule.Dentist+"//"+
                StaticUserModule.Operation+"//"+
                StaticUserModule.others+"//"+
                StaticUserModule.Gender+"//"+
                StaticUserModule.DateofBirth+"//"+
                StaticUserModule.City;
        FileOutputStream file=null;
        try {
            file=openFileOutput("user",MODE_PRIVATE);
            file.write(text.getBytes());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        finally {
            file.close();
        }
    }
}

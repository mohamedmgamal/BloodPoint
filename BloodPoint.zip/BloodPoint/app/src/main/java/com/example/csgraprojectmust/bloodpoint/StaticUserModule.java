package com.example.csgraprojectmust.bloodpoint;

public  class StaticUserModule {
    public   static String UserName="",
            Password="",
            DateofBirth="",
            MobileNumber="",
            Gender="",
            BloodType="",
            City="",
            lastMedicalChick="dontKnow"
            ,lastDonation="",
            location="",
            id="0";
    public static boolean  Dentist=false;
    public static boolean Virusc=false;
    public static boolean others=false;
    public static boolean Operation=false;
    public static boolean medicalAvailability=true;


}

package com.example.csgraprojectmust.bloodpoint;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class ResiveRequest extends AppCompatActivity {
   private TextView txt_rerecipientNameInReseve,txt_rerecipintPhonenumberInReseve,
            txt_Hospital,txt_City,txt_BloodGroup,txt_Age,txt_Date;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resive_request);
        Intent start=new Intent(this,Setviece.class);
        stopService(start);
        txt_rerecipientNameInReseve=findViewById(R.id.txt_rerecipientNameInReseve);
        txt_rerecipintPhonenumberInReseve=findViewById(R.id.txt_rerecipintPhonenumberInReseve);
        txt_Hospital=findViewById(R.id.txt_Hospital);
        txt_City=findViewById(R.id.txt_City);
        txt_BloodGroup=findViewById(R.id.txt_BloodGroupp);
        txt_Age=findViewById(R.id.txt_Age);
        txt_Date=findViewById(R.id.txt_Date);

        txt_rerecipientNameInReseve.setText(StaticRequestModule.name);
        txt_rerecipintPhonenumberInReseve.setText(StaticRequestModule.mobileNumber);
        txt_Hospital.setText(StaticRequestModule.hospital);
        txt_City.setText(StaticRequestModule.city);
        txt_BloodGroup.setText(StaticRequestModule.bloodbags);
        txt_Age.setText(StaticRequestModule.age);
        txt_Date.setText(StaticRequestModule.date);

    }

    public void acceptRequest(View view) {
        Home.Switch_Availability.setChecked(false);
        Home.Availability=false;
        StaticRequestModule.oldnumber0fBB=StaticRequestModule.number0fBB;
        Toast.makeText(this,StaticRequestModule.number0fBB,Toast.LENGTH_SHORT).show();
        FireBaseFunctions.AddAcceptance(StaticUserModule.UserName,StaticUserModule.MobileNumber
        ,StaticUserModule.City);
        StaticRequestModule.oldnumber0fBB=StaticRequestModule.number0fBB;
        FireBaseFunctions.updateWhenAcceptRequest();
        Home.RequestMaade=true;
        Home.btn_currentDonation.setVisibility(View.VISIBLE);
        Intent directions=new Intent(this,GetDirictions.class);
        startActivity(directions);
        finish();
    }

    public void skip(View view) {
        StaticRequestModule.SkipedmobileNumber=StaticRequestModule.mobileNumber;
        StaticRequestModule.mobileNumber="0";
        Home.Switch_Availability.setChecked(true);
        Home.Availability=true;
        Intent start=new Intent(this,Setviece.class);
        startService(start);
        finish();
    }
}

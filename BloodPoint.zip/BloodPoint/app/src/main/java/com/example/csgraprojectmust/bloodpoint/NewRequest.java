package com.example.csgraprojectmust.bloodpoint;

import android.app.DatePickerDialog;
import android.arch.lifecycle.AndroidViewModel;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.text.BreakIterator;
import java.util.Calendar;

public class NewRequest extends AppCompatActivity {
private EditText txt_RecepentName,txt_RecepenPhoneNumber,txt_recepientAge;
private RadioGroup GenderRG;
private Spinner Spinner_City,Spinner_Hospital,Spinner_NumberDonors,Spinner_BloodGroup;
private RadioButton male,female;
private String city,bloodGroup,hospital,gender=StaticUserModule.Gender,numberOfDonors;
    private Calendar calendar2;
    String []HospitalsCairo=new String[]{"","المعهد القومى للاورام","الياسمين","الحسين","القصر العينى","المنيل الجامعى","معهد ناصر","57357","الهلال","ابو الريش","الدره للقلب","البنك الاهلى","المقاولون العرب","السلام الدولى","القاهره التخصصى","النزهه الدولى","سان بيتر الدولى","هليوبوليس","الجنزورى","النيل البدراوى","الايطالى","مصر للطيران",
            "الجمهوريه","القبطى","الكهرباء","الجلاء للقوات المسلحه"};
    String []HospitalsGiza=new String[]{"","الزراعيين","العجوزه","مصر الدولى","السلام بالمهندسين","الشبراويشى"
            ,"الامل","المروه","الشرق","لبنان التخصصى","مكه","ام المصريين",
    "سعاد كفافي الجامعي","جامعة 6 اكتوبر","زايد التخصصي"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_request);
        txt_RecepentName=findViewById(R.id.txt_rerecipientName);
        txt_recepientAge=findViewById(R.id.txt_recepientAge);
        txt_RecepenPhoneNumber=findViewById(R.id.txt_rerecipintPhonenumber);
        GenderRG=findViewById(R.id.gender2);
        Spinner_BloodGroup=findViewById(R.id.Spinner_BloodGroub);
        Spinner_City=findViewById(R.id.Spinner_City);
        Spinner_Hospital=findViewById(R.id.Spinner_Hospital);
        Spinner_NumberDonors=findViewById(R.id.Spinner_numberOfDonors);
        txt_RecepentName.setText(StaticUserModule.UserName);
        txt_RecepenPhoneNumber.setText(StaticUserModule.MobileNumber);
        male=findViewById(R.id.Male2);
        female=findViewById(R.id.Female2);
        if(StaticUserModule.Gender.equals("Male"))
            male.setChecked(true);
        else
         female.setChecked(true);

        ////////////////////////////////////////////////////////////////////////////
        ArrayAdapter<CharSequence> BloodG = ArrayAdapter.createFromResource(this, R.array.bloodgroup, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> adaptercity = ArrayAdapter.createFromResource(this, R.array.Citys, android.R.layout.simple_spinner_item);
        Spinner_BloodGroup.setAdapter(BloodG);
        Spinner_City.setAdapter(adaptercity);
        Adapter numbers=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item);
        ((ArrayAdapter) numbers).add("1");((ArrayAdapter) numbers).add("2");((ArrayAdapter) numbers).add("3");
        Spinner_NumberDonors.setAdapter((SpinnerAdapter) numbers);
        Spinner_City.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i)
                {
                    case 0:
                        city="Cairo";
                        break;
                    case 1:
                        city="Giza";
                        break;
                    case 2:
                        city="Sharqia";
                        break;
                    case 3:
                        city="Dakahlia";
                        break;
                    case 4:
                        city="Behira";
                        break;
                    case 5:
                        city="Minya";
                        break;
                    case 6:
                        city="Qalyubia";
                        break;
                    case 7:
                        city=("Alexandria");
                        break;
                    case 8:
                        city=("Gharbia");
                        break;
                    case 9:
                        city=("Sohag");
                        break;
                    case 11:
                        city=("Asyut");
                        break;
                    case 12:
                        city=("Mnoufia");
                        break;
                    case 13:
                        city=("Kafr El Shekikh");
                        break;
                    case 14:
                        city=("Fayium");
                        break;
                    case 15:
                        city=("Quena");
                        break;
                    case 16:
                        city=("BeniSuef");
                        break;
                    case 17:
                        city=("Aswan");
                        break;
                    case 18:
                        city=("Dasmietta");
                        break;
                    case 19:
                        city=("Ismailia");
                        break;
                    case 20:
                        city=("Luxor");
                        break;
                    case 21:
                        city=("PortSaid");
                        break;
                    case 22:
                        city=("Suez");
                        break;
                    case 23:
                        city=("Matrouh");
                        break;
                    case 24:
                        city=("NorthSini");
                        break;
                    case 25:
                        city=("SouthSini");
                        break;
                    case 26:
                        city=("RedSea");
                        break;
                    case 27:
                        city=("NewValue");
                        break;



                }}

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        ///////////////////////////////////////////////////////////////
       Adapter Hospitals=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item);
        if (StaticUserModule.City.equals("Cairo"))
            ((ArrayAdapter) Hospitals).add(HospitalsCairo);
        else if (StaticUserModule.City.equals("Giza"))
           ((ArrayAdapter) Hospitals).add(HospitalsGiza);
        Spinner_Hospital.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                StaticRequestModule.hospital=Spinner_Hospital.getSelectedItem().toString();
            }
        });
        ////////////////////////////////////////////////////////////////////////////////////////////
        Spinner_BloodGroup.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0:
                        bloodGroup="Any";
                        break;
                    case 1:
                        bloodGroup="A+";
                        break;
                    case 2:
                        bloodGroup="A-";
                        break;
                    case 3:
                        bloodGroup="B+";
                        break;
                    case 4:
                        bloodGroup="B-";
                        break;
                    case 5:
                        bloodGroup="O+";
                        break;
                    case 6:
                        bloodGroup="O-";
                        break;
                    case 7:
                        bloodGroup="AB+";
                        break;
                    case 8:
                        bloodGroup="AB-";
                        break;

                } }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        Spinner_NumberDonors.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0:numberOfDonors="1";
                        break;
                    case 1:numberOfDonors="2";
                        break;
                    case 2:numberOfDonors="3";
                        break;

                } }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        GenderRG.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i){
                    case R.id.Male2:
                        gender="Male";
                        break;
                    case R.id.Female2:
                        gender="Female";
                        break;
                }
            }
        });
                calendar2=Calendar.getInstance();
                StaticRequestModule.date= calendar2.get(Calendar.DAY_OF_MONTH)+"/"+calendar2.get(Calendar.MONTH)+"/"+calendar2.get(Calendar.YEAR);




    }





    public void request(View view) {
       if (txt_RecepenPhoneNumber.getText().toString().isEmpty())
       {   txt_RecepenPhoneNumber.setError("Empty Field");
       return;}
       else if (txt_RecepentName.getText().toString().isEmpty())
       {   txt_recepientAge.setError("Empty Field");
           return;}
       else if (txt_recepientAge.getText().toString().isEmpty())
       {   txt_recepientAge.setError("Empty Field");
           return;}
       StaticRequestModule.age=txt_recepientAge.getText().toString();
        StaticRequestModule.name=txt_RecepentName.getText().toString();
        if(!txt_RecepenPhoneNumber.getText().toString().contains("+2"))
            StaticRequestModule.mobileNumber="+2"+txt_RecepenPhoneNumber.getText().toString();
        else
            StaticRequestModule.mobileNumber=txt_RecepenPhoneNumber.getText().toString();
        StaticRequestModule.gender=gender;
        StaticRequestModule.bloodbags=bloodGroup;
        StaticRequestModule.city=city;
        StaticRequestModule.hospital=hospital;
        StaticRequestModule.number0fBB=numberOfDonors;
        StaticRequestModule.area=city;
       // StaticRequestModule.hospital="Soaad kfafi";
        StaticRequestModule.oldnumber0fBB=StaticRequestModule.number0fBB;
        FireBaseFunctions.RequestAddToDataBase();
        FireBaseFunctions.RequestInfoAddToDataBase();
        Home.Availability=false;
        Home.Switch_Availability.setChecked(false);
        Home.RequestMaade=true;
        Home.currentRequest=true;
        Toast.makeText(this,"sending Request ",Toast.LENGTH_SHORT).show();
        Intent home=new Intent(this,Home.class);
        startActivity(home);
        finish();

    }
}

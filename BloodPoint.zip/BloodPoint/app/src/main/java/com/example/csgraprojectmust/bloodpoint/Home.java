package com.example.csgraprojectmust.bloodpoint;

import android.content.Intent;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataOutputStream;

public class Home extends AppCompatActivity {
private DrawerLayout drawer;
TextView UserName;
static ImageButton  btn_currentRequest,btn_currentDonation;
static Switch Switch_Availability;
static boolean Availability=false,currentRequest=false,RequestMaade=false;
@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer=findViewById(R.id.HomeActivity);
        final Intent medicalStatue=new Intent(this,medical2_Activity.class);
    Switch_Availability=findViewById(R.id.Switch_Availability);
        NavigationView navigationView=findViewById(R.id.nav_view);
        View headerview=navigationView.getHeaderView(0);
        UserName=(TextView)headerview.findViewById(R.id.userName);
        UserName.setText(StaticUserModule.UserName);
        //////////////////////////////////////////////////
    btn_currentRequest=findViewById(R.id.btn_currentRequest);
    btn_currentDonation=findViewById(R.id.btn_currentDonation);
   final Intent currentReques1t=new Intent(this,CurrentRequest.class);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()){
                    case R.id.item_Profile:Profile();
                        break;
                    case R.id.item_MedicalStatue:startActivity(medicalStatue);
                        break;
                    case R.id.current_Orders:currentRequest();
                        break;
                    case R.id.about:info();
                        break;
                    case R.id.sighnOut:deleteAppData();
                        break;




                }
                return true;
            }
        });
        ActionBarDrawerToggle toggle=new ActionBarDrawerToggle(this,drawer,toolbar,
                R.string.navigation_drawer_open,R.string.navigation_drawer_close);
    drawer.addDrawerListener(toggle);
    toggle.syncState();
    show();
    }
    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
@Override
public void onResume(){
    super.onResume();
    show();
}
    void func(String whaterver){
    Toast.makeText(this,whaterver,Toast.LENGTH_SHORT).show();

}
    private void deleteAppData() {
        try {
            // clearing app data
            String packageName = getApplicationContext().getPackageName();
            Runtime runtime = Runtime.getRuntime();
            runtime.exec("pm clear "+packageName);

        } catch (Exception e) {
            e.printStackTrace();
        } }
    public void newRequest(View view) {
    Intent newRequest=new Intent(this,NewRequest.class);
    startActivity(newRequest);
    }
    public void Availability(View view) {
    if (!StaticUserModule.medicalAvailability==true)
    {Toast.makeText(this,"You Have Medial issues and cant Donate",Toast.LENGTH_SHORT).show();
    Switch_Availability.setChecked(false);}
    else{
        if (!RequestMaade){
        if(Switch_Availability.isChecked())
        {
            Availability=true;
            Toast.makeText(this,"Enable Availability",Toast.LENGTH_SHORT).show();
            Intent start=new Intent(this,Setviece.class);
            startService(start);}
        else {Availability=false;
            Intent start=new Intent(this,Setviece.class);
            stopService(start);}}
        else {
            Switch_Availability.setChecked(false);
            Toast.makeText(this, "You are making a Aequest", Toast.LENGTH_SHORT).show();

        }
    }
    }
    public void Dirictions(View view) {
        Intent directions=new Intent(this,GetDirictions.class);
        startActivity(directions);
    }
    public void show(){
    if (currentRequest==true)
        btn_currentRequest.setVisibility(View.VISIBLE);
    else
      btn_currentRequest.setVisibility(View.INVISIBLE);
    }
    public void CurrentRequest(View view) {
        currentRequest();

    }
    private void currentRequest(){
        FireBaseFunctions.LoadReuestInfo();
        Toast.makeText(this,"Loading",Toast.LENGTH_SHORT).show();
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent currentRequest=new Intent(Home.this,CurrentRequest.class);
                startActivity(currentRequest);
            }
        }, 2000);
    }
    private void Profile(){
    Intent profile=new Intent(this,Profile.class);
    startActivity(profile);

    }
private void info(){
    Intent info=new Intent(this,Info.class);
    startActivity(info);
}}